# import pygame, sys, random
import pygame
import sys
import random
from pygame.locals import *  # import pygame modules
pygame.font.init()

clock = pygame.time.Clock()  # set up the clock

# Set up for the game window
pygame.display.set_caption("Game Window")
WINDOW_SIZE = (600, 400)
COLORKEY = (255, 255, 255)
screen = pygame.display.set_mode(WINDOW_SIZE, 0, 32)
display = pygame.Surface((300, 200))
# Create the image for the player model
PlayerImage = pygame.image.load("images/player.png").convert()  # sets player image to player.png
PlayerImage.set_colorkey(COLORKEY)
# Create the images for the tiles
DirtImage = pygame.image.load("images/dirt.png").convert()  # Creates dirt tile
GrassImage = pygame.image.load("images/grass.png").convert()  # Creates grass tile
# this is used later on the program to assign all tile heights and widths to be the same, so the tiles are next to each other with no gaps
size = DirtImage.get_width()
SpikeImage = pygame.image.load("images/spikes.png").convert()  # Creates spike tile
SpikeImage.set_colorkey(COLORKEY)
# Create the different versions for the life
HealthImage3 = pygame.image.load("images/health3.png").convert()
HealthImage3.set_colorkey(COLORKEY)
HealthImage2 = pygame.image.load("images/health2.png").convert()
HealthImage2.set_colorkey(COLORKEY)
HealthImage1 = pygame.image.load("images/health1.png").convert()
HealthImage1.set_colorkey(COLORKEY)
HealthImage0 = pygame.image.load("images/health0.png").convert()
HealthImage0.set_colorkey(COLORKEY)
# creates the background cloud images
Cloud1 = pygame.image.load("images/cloud1.png").convert()
Cloud1.set_colorkey(COLORKEY)
Cloud2 = pygame.image.load("images/cloud2.png").convert()
Cloud2.set_colorkey(COLORKEY)
# creates the fish image for the score
Fish = pygame.image.load("images/Fish.png").convert()
Fish.set_colorkey(COLORKEY)
# creates the image for the jump boosts
Jump = pygame.image.load("images/Jump.png").convert()
Jump.set_colorkey(COLORKEY)
# creates the image that pops up when player wins
win = pygame.image.load("images/win.png").convert()


# Variables and functions to create the fish total on screen
TotalFish = 0
score = 0
font = pygame.font.Font('freesansbold.ttf', 16)


# Object for fish / score
class fish_obj():
    def __init__(self, location):
        self.location = location

    def collision_test(self, rect):  # using the fish location checks if player collides with the fish
        fish_rect = self.get_rect()
        return fish_rect.colliderect(rect)

    def get_rect(self):  # gets the fish location and returns it
        return pygame.Rect(self.location[0], self.location[1], 8, 9)

    def render(self, surf, scroll):  # Renders the fish on the screen surface
        surf.blit(Fish, (self.location[0] - scroll[0], self.location[1] - scroll[1]))


# Object to create jump boosts around map
class Jumpboost_obj():
    def __init__(self, location):
        self.location = location

    def collision_test(self, rect):  # Gets data on where the boosts are located then checks to see if player collides then returns
        jump_rect = self.get_rect()
        return jump_rect.colliderect(rect)

    def get_rect(self):  # Gets the location of the jump boosts to check if player collides
        return pygame.Rect(self.location[0], self.location[1], 8, 9)

    def render(self, surf, scroll):  # Renders the jump boosts
        surf.blit(Jump, (self.location[0] - scroll[0], self.location[1] - scroll[1]))


# function to display the score on the screen
def show_score(x, y):
    Score = font.render("Fish: " + str(score) + " / " + str(TotalFish), True, (255, 153, 51))
    display.blit(Score, (x, y))


# Loads data from text file to create tile map
def load_map():
    m = open("map.txt", "r")  # checks files for a .txt file and opens it
    data = m.read()  # reads the data and sets it as a variable
    m.close()
    data = data.split("\n")  # splits each row into separate rows
    GameMap = []
    for row in data:
        GameMap.append(list(row))  # creates a list of all the rows
    return GameMap


# opens the highscores file to print it out
def load_highscores():
    highscores = open("highscores.txt", "r")
    total = highscores.readlines()
    highscores.close()
    highscores = open("highscores.txt", "r")
    all = highscores.read()
    highscores.close()
    print("There are", len(total), "Highscores")
    print(all)


# adds a highscore to the highscores file
def add_highscores(name="Anonymous "):
    number = str(score) + " / " + str(TotalFish)
    percent = score / TotalFish * 100
    highscores = open("highscores.txt", "a")
    highscores.write(name + number + " = {:.0f}".format(percent) + "%" + "\n")
    highscores.close()


# function to decide if player won or lost and displays the correct menu
def Game_over(result):
    while True:
        display.fill((0, 0, 0))
        text = font.render("GAME OVER, YOU " + str(result), True, (255, 153, 51))
        if result == "WIN!":
            display.blit(win, (0, 0))
            display.blit(text, (65, 80))
        elif result == "DIED!":
            display.blit(text, (65, 80))

        for event in pygame.event.get():  # event loop
            if event.type == QUIT:  # check for window quit
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:  # Checks to see if player presses escape then quits
                    pygame.quit()
                    sys.exit()

        surf = pygame.transform.scale(display, WINDOW_SIZE)
        screen.blit(surf, (0, 0))
        pygame.display.update()  # update display
        clock.tick(60)  # sets window to 60 fps


# creates list of tiles collided with the player rect in the tiles list
def collision_test(rect, tiles):
    collide_list = []
    for tile in tiles:
        if rect.colliderect(tile):
            collide_list.append(tile)
    return collide_list


# checks for tiles that should damage the player and add it to a list if collided with it
def dmg_test(rect, tiles):
    dmg_list = []
    for tile in tiles:
        if tile in DmgTiles:
            dmg_list.append(tile)
    return dmg_list


# function to determine the direction of the collided tile and changes the dictionary values
# Source where I found out how to do collisions https://www.youtube.com/watch?v=Qdeb1iinNtk
def move(rect, movement, tiles):
    CollisionTypes = {"Top": False, "Bottom": False, "Right": False, "Left": False, "Dmg": False}
    rect.x += movement[0]
    collide_list = collision_test(rect, tiles)
    dmg_list = dmg_test(rect, tiles)
    for tile in collide_list:
        if movement[0] > 0:  # checks to see if the player collides from the right of the tile
            rect.right = tile.left
            CollisionTypes["right"] = True
        elif movement[0] < 0:  # checks to see if the player collides from the left of the tile
            rect.left = tile.right
            CollisionTypes["left"] = True
    rect.y += movement[1]
    collide_list = collision_test(rect, tiles)
    for tile in collide_list:
        if movement[1] > 0:  # checks to see if the player collides from the bottom of the tile
            rect.bottom = tile.top
            CollisionTypes["Bottom"] = True
            if tile in dmg_list:
                CollisionTypes["Dmg"] = True
        elif movement[1] < 0:  # checks to see if the player collides from the top of the tile
            rect.top = tile.bottom
            CollisionTypes["Top"] = True

    return rect, CollisionTypes


# setting default values of certain variables
MoveRight = False
MoveLeft = False
Health = 3
PlayerMomentum = 0
air_timer = 0
scroll = [0, 0]
# gets the width and height of the player image so it creates the correct rect for the character to check for collisons
player_rect = pygame.Rect(130, 290, PlayerImage.get_width(), PlayerImage.get_height())

# randomly generating where the jump boosts should be
jump_obj = []
for i in range(6):
    jump_obj.append(Jumpboost_obj((random.randint(16, 1008), random.randint(140, 300))))

# randomly assigns 0 (air) tiles to fish
fish_objects = []
y = 0
# Creates variable from the data collected from the text file
GameMap = load_map()
for row in GameMap:
    x = 0
    for tile in row:
        if tile == "0":
            gen = random.randint(1, 25)
            if gen == 25:
                TotalFish += 1
                fish_objects.append(fish_obj((x * size, y * size)))
        x += 1
    y += 1
# checks to see if the client is running then starts the game loop
running = True
while running:  # game loop
    display.fill((157, 215, 239))  # sets background colour to blue

# scroll mechanic so the screen moves with the player model
    scroll[0] += (player_rect.x-scroll[0]-140)
    scroll[1] += (player_rect.y-scroll[1]-90)

# This is the code for the cloud background with the parallax effect
# Source where I learnt how to do this: https://www.youtube.com/watch?v=5q7tmIlXROg
    background_obj = [[0.25, [150, 10]], [0.25, [340, 30]], [0.5, [40, 40]], [0.5, [110, 90]], [0.5, [260, 80]],
                      [0.25, [240, 225]], [0.25, [560, 215]], [0.5, [60, 220]], [0.5, [260, 245]], [0.5, [600, 240]]]
    for cloud in background_obj:
        if cloud[0] == 0.5:
            obj_rect = pygame.Rect(cloud[1][0]-scroll[0]*cloud[0],
                                   cloud[1][1]-scroll[1]*cloud[0],
                                   Cloud1.get_width(), Cloud1.get_height())
            display.blit(Cloud1, obj_rect)
        elif cloud[0] == 0.25:
            obj_rect = pygame.Rect(cloud[1][0] - scroll[0] * cloud[0],
                                   cloud[1][1] - scroll[1] * cloud[0],
                                   Cloud2.get_width(), Cloud2.get_height())
            display.blit(Cloud2, obj_rect)

# looks at the list of all the rows and goes through each value and assigns them to the correct tile image,
# also adds the tiles that should be solid and tiles that should damage to a list
# Source to creating tile maps https://www.youtube.com/watch?v=abH2MSBdnWc&t=1s
    CollisionTiles = []
    DmgTiles = []
    y = 0
    for row in GameMap:
        x = 0
        for tile in row:
            if tile == "1":
                display.blit(DirtImage, (x * size-scroll[0], y * size-scroll[1]))
            if tile == "2":
                display.blit(GrassImage, (x * size-scroll[0], y * size-scroll[1]))
            if tile == "3":
                display.blit(SpikeImage, (x * size-scroll[0], y * size-scroll[1]))
                DmgTiles.append(pygame.Rect(x * size, y * size, size, size))
            if tile != "0":
                CollisionTiles.append(pygame.Rect(x * size, y * size, size, size))
            x += 1
        y += 1


# Movement calculations for player (and stores it in player movement list)
    PlayerMovement = [0, 0]
    if MoveRight:
        PlayerMovement[0] += 3
    if MoveLeft:
        PlayerMovement[0] -= 2.2
    PlayerMovement[1] += PlayerMomentum
    PlayerMomentum += 0.2
    if PlayerMomentum > 4:  # sets a cap on player momentum of 4
        PlayerMomentum = 4

# flips the player image depending on the key pressed
    player_flip = False
    if PlayerMovement[0] > 0:
        player_flip = False
    if PlayerMovement[0] < 0:
        player_flip = True

# checks for the player and collisions location and uses the move function to check what direction the collision is from
    player_rect, collisions = move(player_rect, PlayerMovement, CollisionTiles)

# depending on the collision direction it changes the way the  momentum works for the player
    if collisions["Bottom"]:
        PlayerMomentum = 0.
        air_timer = 0
    else:
        air_timer += 1
    if collisions["Top"]:
        PlayerMomentum = 0.2
    if collisions["Dmg"]:
        Health -= 1
        PlayerMomentum = -3

    # assigns the right health image depending on the players health
    if Health == 3:
        HealthImage = HealthImage3
    elif Health == 2:
        HealthImage = HealthImage2
    elif Health == 1:
        HealthImage = HealthImage1
    elif Health <= 0:
        HealthImage = HealthImage0
# this displays the player model
    display.blit(pygame.transform.flip(PlayerImage, player_flip, False), (player_rect.x-scroll[0], player_rect.y-scroll[1]))  # render player
    display.blit(HealthImage, (0, 178))  # Render lives at the bottom
    show_score(140, 185)

# Renders the jump boosts and boosts player when they collide
    for jumpboost in jump_obj:
        jumpboost.render(display, scroll)
        if jumpboost.collision_test(player_rect):
            PlayerMomentum = -6

# Renders the fish and detects when player collides then adds score
    for fish in fish_objects:
        fish.render(display, scroll)
        if fish.collision_test(player_rect):
            score += 1
            fish_objects.remove(fish)

# the loop to check for player key presses to move player model
    for event in pygame.event.get():  # event loop
        if event.type == QUIT:  # check for window quit
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            if event.key == K_d:  # Checks to see if player presses d then move right
                MoveRight = True
            if event.key == K_a:  # Checks to see if player presses a then move left
                MoveLeft = True
            if event.key == K_w:  # Checks to see if player presses w then reduce momentum to simulate jumping
                if air_timer < 6:  # Can't jump if not touching the ground
                    PlayerMomentum = -5
        if event.type == KEYUP:
            if event.key == K_d:
                MoveRight = False
            if event.key == K_a:
                MoveLeft = False

# creates a surface on the display for rects to print on
    surf = pygame.transform.scale(display, WINDOW_SIZE)
    screen.blit(surf, (0, 0))
    pygame.display.update()  # update display
    clock.tick(60)  # sets window to 60 fps
# if statement to check if the player has won or died

    if score == TotalFish:
        result = "WIN!"
        print(result)
        name = input("Whats your name? ") + " "
        add_highscores(name)
        load_highscores()
        Game_over(result)

    elif Health <= 0:
        result = "DIED!"
        print(result)
        add_highscores()
        load_highscores()
        Game_over(result)
